library(cowplot)
require(DT)
require(highcharter)
require(htmltools)
require(readr)
library(readxl)
require(rsconnect)
library(scales)
require(shiny)
require(shinydashboard)
require(shinyWidgets)
library(stats)
library(tidyverse)
library(xfun)

#install.packages("readxl")

#dt <- read_excel("C:/Users/hugoh/Downloads/teste/Tomate.xlsx")

#Tomate_1_ <- read_excel("C:/Users/Adriane/Downloads/Tomate (1).xlsx")
#View(Tomate_1_)

Tomate_1_ <- read_excel("Tomate.xlsx")
df1 <- read.csv("df_n_frutos_cum.csv")

dt = Tomate_1_

tratamentos = c(1,3,5,7,9,12,2,4,6,8,10,11)
blocos = c(1,2,3)

# slopes <- matrix(nrow = 10, ncol = 3) # Inclinações das retas
slopes_ <- c()
tratamentos_ <- c()
blocos_ <- c()
colheitas_ <- c()

for(i in tratamentos){
  for(j in blocos){
    df_trat <- df1 %>% filter(tratamento == i & bloco == j)
    fit <- lm(n_frutos_cum ~ colheita + 0, data = df_trat)
    
    tratamentos_ <- c(tratamentos_, i)
    blocos_ <- c(blocos_, j)
    slopes_ <- c(slopes_, fit$coefficients)
    colheitas_ <- c(colheitas_, ifelse(i != 12 & i %% 2 == 0 | i == 11, "alternada", "completa"))
  }
}

df_slopes <- data.frame(tratamento = factor(tratamentos_),
                        bloco = factor(blocos_), slope = slopes_,
                        colheita = colheitas_)


lab = c("1" = "Bloco 1", "2" = "Bloco 2", "3" = "Bloco 3")
#teste
 #ibge <- read.csv("estadosibge.csv", header=T,sep=",")
 #testeee <- read.csv("produtos.csv", header=T,sep=",")
# data <- read.csv("notas_enem.csv", header=T,sep=";")
# dadosc <- read.csv("Produ_estados.csv", header=T,sep=";")
# attach(data)


ui <- dashboardPage(
  skin = "red",
  dashboardHeader(title = "Tomate Mecânico app"),
  dashboardSidebar(dashboardSidebar(sidebarMenu(
    menuItem("Introdução", tabName = "inicio", icon = icon("home")),
    menuItem("Curiosidades", tabName = "curiosidades", icon = icon("book")),
    menuItem("Objetivos", tabName = "objetivo", icon = icon("chart-bar")),
    menuItem("Upload de Base", tabName = "mapa3", icon = icon("database")),
    menuItem("Análises", tabName = "mapa5", icon = icon("chart-area"),
             menuSubItem('Dados', tabName = 'dados', icon = icon('chart-area')),
             menuSubItem('Por colheita', tabName = 'colheita', icon = icon('chart-area')),
             menuSubItem('Ao longo do tempo', tabName = 'tempo', icon = icon('chart-area')),
             menuSubItem('Modelagem', tabName = 'model', icon = icon('chart-area'))),
    menuItem("Informações do experimento", tabName = "sobre", icon = icon("info"))))),
  dashboardBody(
    tags$head(tags$style(HTML(".fa-chart-bar { color: #00FF7F ;}")),
              tags$style(HTML(".fa-chart-line { color: #D8BFD8;}")),
              tags$style(HTML(".fa-chart-area { color: #FF1493;}")),
              tags$style(HTML(".fa-database { color: #FF8C00;}")),
              tags$style(HTML(".fa-info { color: #008BC8;}"))#change the font size to 20
              ),
    tabItems(
      
      tabItem(tabName = "inicio",
              mainPanel(
                fluidRow(column(width = 12, h1("Introdução"), br(), h4(""))),
                box(width = 4,height = "100%", background = "olive",align= "justify", style="position:relative;width:100%;height:0;padding-bottom:100.75%;",
                    "O tomate está entre umas das hortaliças mais consumidas do Brasil. A sua produção é uma atividade agrícola de grande importância econômica e social. Destaca-se por ser uma planta cultivada em quase todos os países, ocupando assim o 9º lugar em produção. Estima-se que em 2000 se produziu aproximadamente 3,04 milhões de toneladas de tomate. (Carvalho, 2002)."),
                box(width = 4, height = "100%", background = "olive",align= "justify", style="position:relative;width:100%;height:0;padding-bottom:100.75%;",
                    "Ao longo dos anos, produtores têm buscado aprimorar as técnicas de cultivo e manejo, visando a obtenção de colheitas mais produtivas e de melhor qualidade. Nesse contexto, a adubação desempenha um papel fundamental, fornecendo nutrientes essenciais para o desenvolvimento saudável das plantas e maximizando o rendimento das culturas."),
                box(width = 8, height = "100%", background = "olive",align= "justify", style="position:relative;width:100%;height:0;padding-bottom:40.75%;",
                    "Para haver êxito na alta produtividade é necessário a utilização adequada de nutrientes, entre eles estão o nitrogênio (N), o potássio (K). Vale destacar que o tomateiro é uma espécie muito exigente em adubação; por isso, é necessário conhecer as necessidades nutricionais de cada local, para não haver um excesso de algum nutriente e torne os demais ineficazes, influenciando assim na produtividade da planta (Moreira et al., 2019)."),
                )),
      
      tabItem(tabName = "curiosidades",
              mainPanel(fluidRow(column(width = 12, h1("Curiosidades"), br(), h4(""))),
                        box(width = 4,height = "100%", background = "light-blue",align= "justify", style="position:relative;width:100%;height:0;padding-bottom:40.75%;",
                            "O tomate gaúcho também é conhecido como tomate caqui. É um tipo que costuma ser graúdo, alguns chegam a pesar quase 500 g"),
                        box(width = 4, height = "100%", background = "light-blue",align= "justify", style="position:relative;width:100%;height:0;padding-bottom:40.75%;",
                            "O tomate gaúcho é uma fruta, assim como todos os outros tipos de tomate. Ele é o fruto da planta tomateiro, que é uma planta fanerógama, com flor, angiosperma."),
                        box(width = 4, height = "100%", background = "light-blue",align= "justify", style="position:relative;width:100%;height:0;padding-bottom:40.75%;",
                            "O tomate gaúcho é originário das Américas, assim como todos os outros tipos de tomate. Ele foi levado para a Europa pelos colonizadores no século XVI."),
                        box(width = 4, height = "100%", background = "light-blue",align= "justify", style="position:relative;width:100%;height:0;padding-bottom:40.75%;",
                            "O tomate gaúcho é um tipo de tomate rasteiro, que é cultivado principalmente no Nordeste e em Goiás"),
                        box(width = 4, height = "100%", background = "light-blue",align= "justify", style="position:relative;width:100%;height:0;padding-bottom:40.75%;",
                            "O tomate gaúcho é rico em licopeno, um antioxidante natural que pode prevenir alguns tipos de câncer e doenças cardiovasculares"),
                        )),
      
      tabItem(tabName = "objetivo",
              mainPanel(fluidRow(column(width = 10, h1("Objetivos"), br(), h4(""))),
                        box(width = 8,height = "100%", background = "yellow",align= "justify",
                            "Neste contexto, o presente estudo se propõe a investigar os efeitos da adubação com nitrogênio, potássio e bioprodutos na produção de tomates na região do Rio Grande do Sul. Dessa forma, espera-se que os resultados desta pesquisa possam contribuir para o aprimoramento das práticas agrícolas relacionadas à adubação de tomates no Rio Grande do Sul. Assim, promovendo a otimização dos recursos utilizados, a minimização de impactos ambientais e o fortalecimento do setor produtivo, visando alcançar maior sustentabilidade e produtividade no cultivo de tomates na região."),
                        box(width = 8,height = "100%", background = "yellow",align= "justify",
                        "Possíveis questionamentos que podemos responder com a análise descritiva e a modelagem estatística: 
                        -	Qual tratamento retorna a maior produtividade?
                        -	Existe alguma estação do ano que favorece o cultivo?
                        -	Ao longo das colheitas em alguma delas não houveram frutos?
                        -	Qual minha produtividade até uma colheita de interesse?
                        -	Outros…"),
                        )),
      
      tabItem(tabName = "dados",
              
              fluidPage(box(width = 12, title = "Dataset Tomate", dataTableOutput("tab2"))),
              
              fluidPage(box(width = 12, column(12, align = "center",
                                               tags$p("T1 = 30 kg. ha-1 de N e K2O de 15 em 15 dias + 0,5 L. ha-1 de bioproduto em todas as colheitas;"),
                                               tags$p("T2 = 30 kg. ha-1 de N e K2O de 15 em 15 dias + 0,5 L. ha-1 de bioproduto em colheitas alternadas;"),
                                               tags$p("T3 = 30 kg. ha-1 de N e K2O de 15 em 15 dias + 1,0 L. ha-1 de bioproduto em todas as colheitas;"),
                                               tags$p("T4 = 30 kg. ha-1 de N e K2O de 15 em 15 dias + 1,0 L. ha-1 de bioproduto em colheitas alternadas;"),
                                               tags$p("T5 = 30 kg. ha-1 de N e K2O de 15 em 15 dias + 1,5 L. ha-1 de bioproduto em todas as colheitas;"),
                                               tags$p("T6 = 30 kg. ha-1 de N e K2O de 15 em 15 dias + 1,5 L.ha-1 de bioproduto em colheitas alternadas;"),
                                               tags$p("T7 = 30 kg. ha-1 de N e K2O de 15 em 15 dias + 2,0 L.ha-1 de bioproduto em todas as colheitas;"),
                                               tags$p("T8 = 30 kg. ha-1 de N e K2O de 15 em 15 dias + 2,0 L.ha-1 de bioproduto em colheitas alternadas;"),
                                               tags$p("T9 = 30 kg. ha-1 de N e K2O de 15 em 15 dias + 2,5 L.ha-1 de bioproduto em todas as colheitas;"),
                                               tags$p("T10 = 30 kg. ha-1 de N e K2O de 15 em 15 dias + 2,5 L. ha-1 de bioproduto em colheitas alternadas; T"),
                                               tags$p("T11 = Testemunha adicional 1. 30 kg. ha-1 de N e K2O de 15 em 15 dias + 5,0 L. ha-1 de bioproduto aos 30 e 60 dias após transplante;"),
                                               tags$p("T12 = Testemunha adicional 2. 10 L. ha-1 bioproduto de 15 em 15 dias; PADRÃO= 30 kg. ha-1 de N e K2O de 15 em 15 dias"))))),
      
      tabItem(tabName = "model",
              
              fluidPage(box(width = 12, title = "Coeficientes Angulares", dataTableOutput("tab1"))),
              
              fluidPage(box(title = "Produtividade segundo o tratamento", width = 12, height = 560,
                            plotOutput("plot2", height = 500))),
              
              fluidPage(box(width = 12, title = "Coeficientes do modelo", dataTableOutput("tab3"))),
              
              fluidPage(box(width = 12, title = "ANOVA Alternada", dataTableOutput("tab4"))),
              
              fluidPage(box(title = "Teste de Tukey", width = 12, height = 560,
                            plotOutput("plot3", height = 500))),
              
              fluidPage(box(width = 12, title = "ANOVA Completa", dataTableOutput("tab5"))),
              
              fluidPage(box(title = "Teste de Tukey", width = 12, height = 560,
                            plotOutput("plot4", height = 500)))
              ),
      
      tabItem(tabName = "tempo",
              fluidRow(box(width = 8, height = "100%", plotOutput("plot1")),
                       
                       sidebarPanel(selectInput("database", label = "Database", choices = c("Tomate" = "tomate"))),
                       sidebarPanel(selectInput("var1", label = "Colheita", choices = c("1" = 1, "2" = 2, "3" = 3, "4" = 4,
                                                                                        "5" = 5, "6" = 6, "7" = 7, "8" = 8,
                                                                                        "9" = 9, "10" = 10))),
                       sidebarPanel(selectInput("var2", label = "Estação de Cultivo", choices = c("Primavera-Verão" = "P-V",
                                                                                                  "Outono-Inverno" = "O-I"))))),
      
      tabItem(tabName = "colheita",
              fluidRow(box(width = 12, height = 90,
                           column(4, selectInput("database", label = "Database", choices = c("Tomate" = "tomate"))),
                           column(2, selectInput("var3", label = "Tratamento 1", choices = c("1" = 1, "2" = 2, "3" = 3, "4" = 4,
                                                                                             "5" = 5, "6" = 6, "7" = 7, "8" = 8,
                                                                                             "9" = 9, "10" = 10, "11" = 11, "12" = 12))),
                           column(2, selectInput("var4", label = "Tratamento 2", choices = c("1" = 1, "2" = 2, "3" = 3, "4" = 4,
                                                                                             "5" = 5, "6" = 6, "7" = 7, "8" = 8,
                                                                                             "9" = 9, "10" = 10, "11" = 11, "12" = 12))),
                           column(4, selectInput("var5", label = "Estação de Cultivo", choices = c("Primavera-Verão" = "P-V",
                                                                                                   "Outono-Inverno" = "O-I")))),
                       box(width = 12, height = 620, plotOutput("plot6", height = 600)))),
      
      tabItem(tabName = "mapa3",
              box(width=4,status = "primary", solidHeader = TRUE,
                  fileInput("file1", "Choose one CSV file", multiple = FALSE,
                            accept = c("text/csv", "text/comma-separated-values,text/plain", ".csv, .xslx, .xls")),
                  
                  # Horizontal line ----
                  
                  tags$hr(),
                  
                  # Input: Checkbox if file has header ----
                  
                  checkboxInput("header", "Header (Name/Description of Attributes)", TRUE),
                  
                  # Input: Select separator ----
                  
                  awesomeRadio("sep", "Separator", choices = c(Comma = ",", Semicolon = ";", Tab = "\t"),
                               selected = ",", inline = TRUE),
                  
                  awesomeRadio("identi", "Contains identifier (ID)?", choices = c("Yes", "No"), selected = "No", inline = TRUE),
                  h6("Obs: If yes, we will consider as identifier the first database column.", style = "color: #6A736F;"),
                  ),
              DT::dataTableOutput("contents")),
      
      tabItem(tabName = "sobre",
              mainPanel(h1("Informações"), br(),
                        h4("medidas: N - nitrogênio. K₂O - Óxido de potássio ha^(-1) - 1x hectare.", align= "justify"),
                        h4("Bioproduto - Um bioproduto é um produto de origem biológica derivado da conversão de biomassa por meio de bioprocessos. A biomassa é um material orgânico de origem vegetal, animal ou microbiana", align= "justify"),
                        h4("Peso fruto parcela - o peso está delimitado por gramas, a variável representa a soma dos pesos em g de um parcela.", align= "justify"),
                        h4("Comprimento e largura média - estão delimitados por mm.", align= "justify"),
                        h4("Número de frutos por parcela - o quantitativo de frutos colhidos em uma parcela, de unidade adimensional.", align= "justify"),
                        h4("1 parcela: 10 plantas.", align= "justify"),
                        h4("1 bloco: espaço formado por parcelas, as quais são iguais ao número de tratamentos.", align= "justify"),
                        h4("Espécie dos tomates - tipo gaúcho. ", align= "justify"),
                        h4("Tratamentos - 12 tipos, dos quais 2 são controles", align= "justify")
                        # h4("", align= "justify")
                        ),
              box(width=6,status = "primary", solidHeader = TRUE,  plotOutput("plot7")),
              ))))

server <- function(input, output, session) {
  
  myData <- reactive({
    inFile <- input$file1
    if (is.null(inFile)) {
      # nula <- 0
      return(NULL)
    } else {
      d <- read_xlsx(inFile$datapath)
      
    }
    d
    
  })
  
  output$contents <- DT::renderDataTable({
    #myData()
    DT::datatable(myData(), options = list(orderClasses = TRUE))
    
  })
  
  observe({
    if (!is.null(input$file1)){
      #yblamp <- lamp(myData()[-1])
      updateSelectInput(session, "database",
      choices = c("Tomate" = "tomate",
                  "Sua Base" = "yb"
      ))
      #yblamp <- lamp(myData()[-1])
    } 
  })

  output$tab2 <- DT::renderDataTable({
  
  dt

  })
  
  output$plot1 <- renderPlot({
    input$action
    
    if(input$database == "tomate"){
      mapa = dt %>% filter(`Estação cultivo` == all_of(input$var2) & colheita <= as.numeric(input$var1)) %>%
        group_by(Tratamento, Bloco) %>% arrange(Tratamento, Bloco, colheita) %>%
        mutate(n = cumsum(`nº médio frutos`),
               Bioproduto = case_when(Tratamento %in% c("1", "2") ~ "0.5",
                                      Tratamento %in% c("3", "4") ~ "1.0",
                                      Tratamento %in% c("5", "6") ~ "1.5",
                                      Tratamento %in% c("7", "8") ~ "2.0",
                                      Tratamento %in% c("9", "10") ~ "2.5",
                                      Tratamento %in% c("11") ~ "5.0",
                                      Tratamento %in% c("12") ~ "10"),
               Bioproduto = factor(Bioproduto,
                                   levels = c("0.5", "1.0", "1.5",
                                              "2.0", "2.5", "5.0", "10")),
               COLHEITAS = case_when(Tratamento %in% c(seq(1, 10, 2), 12) ~ "Todas",
                                     Tratamento %in% c(seq(2, 10, 2), 11) ~ "Alternadas")) %>%
        
        ggplot(aes(x = as.factor(colheita), y = n, group = as.factor(Tratamento))) +
        geom_line(aes(colour = Bioproduto, linetype = COLHEITAS), linewidth = 1) +
        geom_point(aes(colour = Bioproduto)) + 
        labs(x = "Colheita", y = "Número acumulado de frutos",
             linetype = "Forma de\ncolheita") +
        facet_wrap(~Bloco, scales = "free_y", nrow = 3,
                   labeller = labeller(Bloco = lab)) + theme_bw() +
        theme(text = element_text(size = 20))
      mapa
    }
    else if(input$var1 == 1 && input$database == "yb" ){ 
      myData()
      
      mapa <- dt %>% filter(`Estação cultivo` == 'P-V' & colheita<=1) %>% group_by(Tratamento, Bloco) %>% 
        arrange(Tratamento, Bloco, colheita) %>%
        mutate(n = cumsum(`nº médio frutos`),
               Bioproduto = case_when(Tratamento %in% c("1", "2") ~ "0.5",
                                      Tratamento %in% c("3", "4") ~ "1.0",
                                      Tratamento %in% c("5", "6") ~ "1.5",
                                      Tratamento %in% c("7", "8") ~ "2.0",
                                      Tratamento %in% c("9", "10") ~ "2.5",
                                      Tratamento %in% c("11") ~ "5.0",
                                      Tratamento %in% c("12") ~ "10"),
               Bioproduto = factor(Bioproduto,
                                   levels = c("0.5", "1.0", "1.5",
                                              "2.0", "2.5", "5.0", "10")),
               COLHEITAS = case_when(Tratamento %in% seq(1, 10, 2) ~ "Todas",
                                     Tratamento %in% seq(2, 10, 2) ~ "Alternadas",
                                     Tratamento %in% c(11, 12) ~ "Padrão")) %>%   ggplot(aes(x = as.factor(colheita), y = n, group = as.factor(Tratamento))) +
        geom_line(aes(colour = Bioproduto, linetype = COLHEITAS), linewidth = 1) +
        geom_point(aes(colour = Bioproduto)) + 
        labs(x = "Colheita", y = "Número acumulado de frutos",
             linetype = "Forma de\ncolheita") +
        facet_wrap(~Bloco, scales = "free_y", nrow = 3,
                   labeller = labeller(Bloco = lab)) + theme_bw() +
        theme(text = element_text(size = 20))
      mapa
      
    }
  })
  
  output$plot6 <- renderPlot({
    input$action
    
    if(input$database == "tomate"){
      lab = c("1" = "Bloco 1", "2" = "Bloco 2", "3" = "Bloco 3")
      
      da = dt %>% filter(`Estação cultivo` == all_of(input$var5)) %>%
        filter(Tratamento %in% c(as.numeric(input$var3),
                                 as.numeric(input$var4)))
      
      mapa = ggplot(da, aes(x = as.factor(colheita), y = `nº médio frutos`, 
                   fill = as.factor(Tratamento))) +
        geom_bar(stat = 'identity', position = 'dodge', color = "black") +
        geom_text(aes(label = number(`nº médio frutos`)), size = 5,
                  vjust = -0.5, position = position_dodge(width = 0.9)) +
        scale_y_continuous(name = "Número de frutos",
                           limits = c(0, max(da$`nº médio frutos`)*1.1)) +
        scale_x_discrete(name = "Colheita", labels = seq(3, 3*10, 3)) +
        scale_fill_brewer(name = "Tratamento", palette = 1) +
        facet_wrap(~Bloco, scales = "free_y", nrow = 3,
                   labeller = labeller(Bloco = lab)) + theme_bw() +
        theme(text = element_text(size = 20),
              legend.position = "bottom")
      
      mapa
    }
    else if(input$var1 == 1 && input$database == "yb" ){ 
      myData()
      
      mapa <- dt %>% filter(`Estação cultivo` == 'P-V' & colheita<=1) %>% group_by(Tratamento, Bloco) %>% 
        arrange(Tratamento, Bloco, colheita) %>%
        mutate(n = cumsum(`nº médio frutos`),
               Bioproduto = case_when(Tratamento %in% c("1", "2") ~ "0.5",
                                      Tratamento %in% c("3", "4") ~ "1.0",
                                      Tratamento %in% c("5", "6") ~ "1.5",
                                      Tratamento %in% c("7", "8") ~ "2.0",
                                      Tratamento %in% c("9", "10") ~ "2.5",
                                      Tratamento %in% c("11") ~ "5.0",
                                      Tratamento %in% c("12") ~ "10"),
               Bioproduto = factor(Bioproduto,
                                   levels = c("0.5", "1.0", "1.5",
                                              "2.0", "2.5", "5.0", "10")),
               COLHEITAS = case_when(Tratamento %in% seq(1, 10, 2) ~ "Todas",
                                     Tratamento %in% seq(2, 10, 2) ~ "Alternadas",
                                     Tratamento %in% c(11, 12) ~ "Padrão")) %>%   ggplot(aes(x = as.factor(colheita), y = n, group = as.factor(Tratamento))) +
        geom_line(aes(colour = Bioproduto, linetype = COLHEITAS), linewidth = 1) +
        geom_point(aes(colour = Bioproduto)) + 
        labs(x = "Colheita", y = "Número acumulado de frutos",
             linetype = "Forma de\ncolheita") +
        facet_wrap(~Bloco, scales = "free_y", nrow = 3,
                   labeller = labeller(Bloco = lab)) + theme_bw() +
        theme(text = element_text(size = 20))
      mapa
      
    }
  })
 
  output$tab1 <- DT::renderDataTable({
    
    tratamentos = c(1,3,5,7,9,12,2,4,6,8,10,11)
    blocos = c(1,2,3)
    
    # slopes <- matrix(nrow = 10, ncol = 3) # Inclinações das retas
    slopes_ <- c()
    tratamentos_ <- c()
    blocos_ <- c()
    colheitas_ <- c()
    
    for(i in tratamentos){
      for(j in blocos){
        df_trat <- df1 %>% filter(tratamento == i & bloco == j)
        fit <- lm(n_frutos_cum ~ colheita + 0, data = df_trat)
        
        tratamentos_ <- c(tratamentos_, i)
        blocos_ <- c(blocos_, j)
        slopes_ <- c(slopes_, fit$coefficients)
        colheitas_ <- c(colheitas_, ifelse(i != 12 & i %% 2 == 0 | i == 11, "alternada", "completa"))
      }
    }
    
    df_slopes <- data.frame(tratamento = factor(tratamentos_),
                            bloco = factor(blocos_), slope = slopes_,
                            colheita = colheitas_)
    
    df_slopes
    
    #mtcars
    
    })

  output$plot2 <- renderPlot({
    
    ggplot(df_slopes)+
      facet_grid(~colheita)+
      geom_boxplot(aes(x = tratamento, y = slope, color = colheita))
    
  })
  
  output$tab3 <- DT::renderDataTable({
    
    fit <- lm(slope ~ tratamento + bloco, data = df_slopes)
    s <- summary(fit)
    s$coefficients
    
  })
  
  output$tab4 <- DT::renderDataTable({
    
    df_alternada <- df_slopes %>% filter(colheita == "alternada") %>% select(c(tratamento, bloco, slope))
    
    model_alternada <- aov(slope ~ tratamento + bloco, data = df_alternada)

    A = summary(model_alternada)
    
    data.frame(A[[1]][1:4], A[[1]][5])
    
  })
  
  output$plot3 <- renderPlot({
    
    plot(TukeyHSD(model_alternada, conf.level=.95, which = "tratamento"), las = 2)
    
  })
  
  output$tab5 <- DT::renderDataTable({
    
    df_completa <- df_slopes %>% filter(colheita == "completa") %>% select(c(tratamento, bloco, slope))
    
    model_completa <- aov(slope ~ tratamento + bloco, data = df_completa)
    A = summary(model_completa)
    data.frame(A[[1]][1:4], A[[1]][5])
    
  })
 
  output$plot4 <- renderPlot({
    
    plot(TukeyHSD(model_completa, conf.level=.95, which = "tratamento"), las = 2)
    
  })
   
}

shinyApp(ui, server)